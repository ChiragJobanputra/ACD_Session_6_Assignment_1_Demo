function CalculateArea() {
  var radius = 3.5;
  var areaOfCircle = radius * radius * Math.PI
  console.log("Area of Circle is: " + "\n" + areaOfCircle);
}
